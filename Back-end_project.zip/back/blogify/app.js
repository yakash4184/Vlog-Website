// This line imports and configures the dotenv package to load environment variables from a .env file.
require("dotenv").config();

// These lines import necessary modules from Node.js and third-party packages.
const path = require("path");
const express = require("express");
const mongoose = require("mongoose");
const cookiePaser = require("cookie-parser");

// This line imports the Blog model from a local file.
const Blog = require("./models/blog");

// These lines import user and blog routes from local files.
const userRoute = require("./routes/user");
const blogRoute = require("./routes/blog");

// This line imports a middleware function for authentication from a local file.
const {
  checkForAuthenticationCookie,
} = require("./middlewares/authentication");

// This creates an Express application instance.
const app = express();

// Defines the port number for the server to listen on, using the PORT environment variable if available, or defaulting to 8000.
const PORT = process.env.PORT || 8000;

// This connects to a MongoDB database using Mongoose.
mongoose
  .connect("mongodb://127.0.0.1:27017/user_management_db")
  .then(() => console.log("connected to MongoDB")) // Logs a message if the connection is successful.
  .catch((err) => console.error("Error connecting to MongoDB:", err)); // Logs an error message if the connection fails.

// Sets up the view engine to use EJS templates.
app.set("view engine", "ejs");

// Sets the directory for views to be resolved.
app.set("views", path.resolve("./views"));

// Middleware to parse incoming request bodies with urlencoded payloads.
app.use(express.urlencoded({ extended: false }));

// Middleware to parse cookies from the request headers.
app.use(cookiePaser());

// Middleware to check for an authentication token cookie in the request.
app.use(checkForAuthenticationCookie("token"));

// Middleware to serve static files such as CSS and images from a directory.
app.use(express.static(path.resolve("./public")));

// Defines a route to handle GET requests to the root URL.
app.get("/", async (req, res) => {
  // Queries the database for all blog posts.
  const allBlogs = await Blog.find({});
  // Renders the "home" view and passes data to it.
  res.render("home", {
    user: req.user, // Passes the user object from the request to the view.
    blogs: allBlogs, // Passes all blog posts to the view.
  });
});

// Defines another route to handle GET requests to the root URL.
app.get("/", (req, res) => {
  // Sends the "blogy.html" file as the response.
  res.sendFile(path.join(__dirname, "blogy.html"));
});

// Mounts the user routes at the /user path.
app.use("/user", userRoute);

// Mounts the blog routes at the /blog path.
app.use("/blog", blogRoute);

// Starts the server and listens on the specified port.
app.listen(PORT, () => console.log(`Server Started at PORT:${PORT}`));
