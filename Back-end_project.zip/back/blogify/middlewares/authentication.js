// Importing the validateToken function from the authentication service.
const { validateToken } = require("../services/authentication");

// Middleware function to check for the presence of an authentication cookie.
function checkForAuthenticationCookie(cookieName) {
  // This function returns another middleware function.
  return (req, res, next) => {
    // Extracting the value of the authentication cookie from the request.
    const tokenCookieValue = req.cookies[cookieName];
    
    // If the authentication cookie is not present, move to the next middleware.
    if (!tokenCookieValue) {
      return next();
    }

    try {
      // Attempting to validate the JWT token extracted from the cookie.
      const userPayload = validateToken(tokenCookieValue);
      
      // If the token is valid, attaching the decoded user payload to the request object.
      req.user = userPayload;
    } catch (error) {
      // If there's an error (e.g., invalid token), ignore it and continue.
    }

    // Moving to the next middleware in the chain.
    return next();
  };
}

// Exporting the checkForAuthenticationCookie middleware function.
module.exports = {
  checkForAuthenticationCookie,
};
