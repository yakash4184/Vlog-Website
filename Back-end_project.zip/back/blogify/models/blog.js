// Importing the Schema and model classes from the mongoose package.
const { Schema, model } = require("mongoose");

// Defining a new mongoose Schema for the 'blog' collection.
const blogSchema = new Schema(
  {
    // Defining a field 'title' of type String which is required.
    title: {
      type: String,
      required: true,
    },
    // Defining a field 'body' of type String which is required.
    body: {
      type: String,
      required: true,
    },
    // Defining a field 'coverImageURL' of type String which is not required.
    coverImageURL: {
      type: String,
      required: false,
    },
    // Defining a field 'createdBy' which references another object in the 'user' collection.
    createdBy: {
      type: Schema.Types.ObjectId,
      ref: "user",
    },
  },
  // Adding timestamps to automatically track 'createdAt' and 'updatedAt' fields.
  { timestamps: true }
);

// Creating a Mongoose model named 'Blog' based on the 'blogSchema'.
const Blog = model("blog", blogSchema);

// Exporting the 'Blog' model to be used in other parts of the application.
module.exports = Blog;
