// Importing the Schema and model classes from the mongoose package.
const { Schema, model } = require("mongoose");

// Defining a new mongoose Schema for the 'comment' collection.
const commentSchema = new Schema(
  {
    // Defining a field 'content' of type String which is required.
    content: {
      type: String,
      required: true,
    },
    // Defining a field 'blogId' which references another object in the 'blog' collection.
    blogId: {
      type: Schema.Types.ObjectId,
      ref: "blog",
    },
    // Defining a field 'createdBy' which references another object in the 'user' collection.
    createdBy: {
      type: Schema.Types.ObjectId,
      ref: "user",
    },
  },
  // Adding timestamps to automatically track 'createdAt' and 'updatedAt' fields.
  { timestamps: true }
);

// Creating a Mongoose model named 'Comment' based on the 'commentSchema'.
const Comment = model("comment", commentSchema);

// Exporting the 'Comment' model to be used in other parts of the application.
module.exports = Comment;
