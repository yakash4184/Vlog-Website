// Importing necessary modules from Node.js and other packages.
const { createHmac, randomBytes } = require("crypto");
const { Schema, model } = require("mongoose");
const { createTokenForUser } = require("../services/authentication");

// Defining a new mongoose Schema for the 'user' collection.
const userSchema = new Schema(
  {
    // Defining a field 'fullName' of type String which is required.
    fullName: {
      type: String,
      required: true,
    },
    // Defining a field 'email' of type String which is required and unique.
    email: {
      type: String,
      required: true,
      unique: true,
    },
    // Defining a field 'salt' of type String.
    salt: {
      type: String,
    },
    // Defining a field 'password' of type String which is required.
    password: {
      type: String,
      required: true,
    },
    // Defining a field 'profileImageURL' of type String with a default value.
    profileImageURL: {
      type: String,
      default: "/images/default.png",
    },
    // Defining a field 'role' of type String with specified enum values and a default value.
    role: {
      type: String,
      enum: ["USER", "ADMIN"],
      default: "USER",
    },
  },
  // Adding timestamps to automatically track 'createdAt' and 'updatedAt' fields.
  { timestamps: true }
);

// Middleware function executed before saving a user document.
userSchema.pre("save", function (next) {
  // Accessing the current user being saved.
  const user = this;

  // If the password is not modified, skip further processing.
  if (!user.isModified("password")) return;

  // Generating a random salt.
  const salt = randomBytes(16).toString();
  
  // Hashing the password using the salt and sha256 algorithm.
  const hashedPassword = createHmac("sha256", salt)
    .update(user.password)
    .digest("hex");

  // Storing the salt and hashed password in the document.
  this.salt = salt;
  this.password = hashedPassword;

  // Calling the next middleware function.
  next();
});

// Static method to find a user by email, validate the password, and generate a token.
userSchema.static(
  "matchPasswordAndGenerateToken",
  async function (email, password) {
    // Finding a user by email.
    const user = await this.findOne({ email });
    // If user not found, throw an error.
    if (!user) throw new Error("User not found!");

    // Retrieving the salt and hashed password from the user document.
    const salt = user.salt;
    const hashedPassword = user.password;

    // Hashing the provided password using the salt.
    const userProvidedHash = createHmac("sha256", salt)
      .update(password)
      .digest("hex");

    // Comparing the hashed passwords.
    if (hashedPassword !== userProvidedHash)
      throw new Error("Incorrect Password");

    // If passwords match, create and return a token for the user.
    const token = createTokenForUser(user);
    return token;
  }
);

// Creating a Mongoose model named 'User' based on the 'userSchema'.
const User = model("user", userSchema);

// Exporting the 'User' model to be used in other parts of the application.
module.exports = User;
