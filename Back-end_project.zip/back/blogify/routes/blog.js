// Importing necessary modules from Express, multer, and path.
const { Router } = require("express");
const multer = require("multer");
const path = require("path");

// Importing the Blog and Comment models.
const Blog = require("../models/blog");
const Comment = require("../models/comment");

// Creating a new router instance.
const router = Router();

// Configuring multer storage options for file uploads.
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    // Set the destination folder for file uploads.
    cb(null, path.resolve(`./public/uploads/`));
  },
  filename: function (req, file, cb) {
    // Generate a unique filename for the uploaded file.
    const fileName = `${Date.now()}-${file.originalname}`;
    cb(null, fileName);
  },
});

// Creating a multer instance with the defined storage options.
const upload = multer({ storage: storage });

// Route to render the form for adding a new blog post.
router.get("/add-new", (req, res) => {
  return res.render("addBlog", {
    user: req.user, // Passes the user object from the request to the view.
  });
});

// Route to fetch and render a specific blog post along with its comments.
router.get("/:id", async (req, res) => {
  // Find the blog post by its ID and populate the 'createdBy' field to get the user who created it.
  const blog = await Blog.findById(req.params.id).populate("createdBy");
  // Find all comments associated with the blog post and populate the 'createdBy' field to get the user who created each comment.
  const comments = await Comment.find({ blogId: req.params.id }).populate(
    "createdBy"
  );

  // Render the 'blog' view and pass the user, blog post, and comments to it.
  return res.render("blog", {
    user: req.user,
    blog,
    comments,
  });
});

// Route to handle adding a comment to a blog post.
router.post("/comment/:blogId", async (req, res) => {
  // Create a new comment with the provided content, associated blog ID, and the ID of the user who created it.
  await Comment.create({
    content: req.body.content,
    blogId: req.params.blogId,
    createdBy: req.user._id,
  });
  // Redirect the user back to the blog post after adding the comment.
  return res.redirect(`/blog/${req.params.blogId}`);
});

// Route to handle creating a new blog post.
router.post("/", upload.single("coverImage"), async (req, res) => {
  // Extract the title and body of the blog post from the request body.
  const { title, body } = req.body;
  // Create a new blog post with the extracted data, the ID of the user who created it, and the URL of the uploaded cover image.
  const blog = await Blog.create({
    body,
    title,
    createdBy: req.user._id,
    coverImageURL: `/uploads/${req.file.filename}`,
  });
  // Redirect the user to the newly created blog post.
  return res.redirect(`/blog/${blog._id}`);
});

// Exporting the router for use in other parts of the application.
module.exports = router;
