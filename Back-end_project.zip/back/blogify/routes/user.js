// Importing necessary modules from Express and the User model.
const { Router } = require("express");
const User = require("../models/user");

// Creating an instance of Express Router.
const router = Router();

// Route for rendering the signin form.
router.get("/signin", (req, res) => {
  return res.render("signin"); // Rendering the signin view.
});

// Route for rendering the signup form.
router.get("/signup", (req, res) => {
  return res.render("signup"); // Rendering the signup view.
});

// Route for handling signin form submission.
router.post("/signin", async (req, res) => {
  const { email, password } = req.body; // Extracting email and password from the request body.
  try {
    // Attempting to authenticate the user and generate a token.
    const token = await User.matchPasswordAndGenerateToken(email, password);

    // Setting a cookie named 'token' with the generated token and redirecting to the home page.
    return res.cookie("token", token).redirect("/");
  } catch (error) {
    // If authentication fails, rendering the signin view with an error message.
    return res.render("signin", {
      error: "Incorrect Email or Password",
    });
  }
});

// Route for handling user logout.
router.get("/logout", (req, res) => {
  // Clearing the 'token' cookie and redirecting to the home page.
  res.clearCookie("token").redirect("/");
});

// Route for handling signup form submission.
router.post("/signup", async (req, res) => {
  const { fullName, email, password } = req.body; // Extracting user details from the request body.
  // Creating a new user with the provided details.
  await User.create({
    fullName,
    email,
    password,
  });
  return res.redirect("/"); // Redirecting to the home page after successful signup.
});

// Exporting the router to be used in other parts of the application.
module.exports = router;
