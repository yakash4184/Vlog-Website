// Importing the JWT module for working with JSON Web Tokens.
const JWT = require("jsonwebtoken");

// Defining a secret key to sign and verify JWT tokens.
const secret = "$uperMan@123";

// Function to create a JWT token for a user.
function createTokenForUser(user) {
  // Creating a payload object containing user data to be encoded into the token.
  const payload = {
    _id: user._id,
    email: user.email,
    profileImageURL: user.profileImageURL,
    role: user.role,
  };
  
  // Generating a JWT token with the payload and the secret key.
  const token = JWT.sign(payload, secret);
  return token; // Returning the generated token.
}

// Function to validate a JWT token.
function validateToken(token) {
  // Verifying the token using the secret key and decoding the payload.
  const payload = JWT.verify(token, secret);
  return payload; // Returning the decoded payload.
}

// Exporting the functions to be used in other parts of the application.
module.exports = {
  createTokenForUser,
  validateToken,
};
